package events;

public class SecurityEvent {

}
